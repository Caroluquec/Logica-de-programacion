
package examen1;
import java.util.Scanner;

public class Examen1 {

  
    public static void main(String[] args) {
        
       Scanner lea= new Scanner (System.in);
       
       String nomb_hijo1,nomb_hijo2,nomb_hijo3,nomb_hijo4,nomb_hijo5;
       Float valor_herencia,valor_hijo1,valor_hijo2,valor_hijo3,valor_hijo4,valor_hijo5;
        System.out.println("Ingrese nombre hijo 1");
        nomb_hijo1= lea.nextLine();
        System.out.println("Ingrese nombre hijo 2");
        nomb_hijo2= lea.nextLine();
        System.out.println("Ingrese nombre hijo 3");
        nomb_hijo3= lea.nextLine();
        System.out.println("Ingrese nombre hijo 4");
        nomb_hijo4= lea.nextLine();
        System.out.println("Ingrese nombre hijo5");
        nomb_hijo5= lea.nextLine();
        System.out.println("Ingrese porcentaje hijo 1");
        porc_hijo1= lea.nextFloat();
        System.out.println("Ingres porcentaje hijo 2");
        porc_hijo2= lea.nextFloat();
        System.out.println("Ingres porcentaje hijo 3");
        porc_hijo3= lea.nextFloat();
        System.out.println("Ingres porcentaje hijo 4");
        porc_hijo4= lea.nextFloat();
        System.out.println("Ingres porcentaje hijo 5");
        porc_hijo5= lea.nextFloat();
        System.out.println("Ingrese valor herencia ");
        System.out.println("Ingrese valor hijo 1 1");
        valor_hijo1= lea.nextFloat();
        System.out.println("Ingrese valor hijo 2");
        valor_hijo2= lea.nextFloat();
        System.out.println("Ingrese valor hijo 3");
        valor_hijo3= lea.nextFloat();
        System.out.println("Ingrese valor hijo 4");
        valor_hijo4= lea.nextFloat();
        System.out.println("Ingrese valor hijo 5");
        valor_hijo5= lea.nextFloat();
        valor_herencia= lea.nextFloat();
        
        valor_hijo1=valor_herencia*10/100;              
        valor_hijo2=valor_herencia*15/100;               
        valor_hijo3=valor_herencia*20/100;
        
        
                
                
        
           
        
                
       
       
       
               
       
               
        
 
        
        
        
    }
    
}
